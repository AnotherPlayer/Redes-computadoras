import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.List;

/**
 * Interfaz gráfica inspirada en la vista de referencia para mostrar los cálculos de subred.
 */
public class CalculatorUI extends JFrame {

    private final JTextField ipField = new JTextField("190.0.0.0");
    private final JTextField hostField = new JTextField("100");

    private final JLabel classValue = createValueLabel("-");
    private final JLabel defaultMaskValue = createValueLabel("-");
    private final JLabel subnetCountValue = createValueLabel("-");
    private final JLabel hostPerSubnetValue = createValueLabel("-");
    private final JLabel newMaskValue = createValueLabel("-");
    private final JLabel prefixValue = createValueLabel("-");

    private final DefaultListModel<String> subnetListModel = new DefaultListModel<>();
    private final DefaultListModel<String> hostListModel = new DefaultListModel<>();
    private final JList<String> subnetList = new JList<>(subnetListModel);
    private final JList<String> hostList = new JList<>(hostListModel);

    private int currentPrefix = -1;
    private String currentIp = "";

    public CalculatorUI() {
        setTitle("Calculadora IP");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1000, 720);
        setLocationRelativeTo(null);

        JPanel content = new JPanel(new BorderLayout(12, 12));
        content.setBorder(new EmptyBorder(14, 14, 14, 14));
        content.setBackground(new Color(63, 132, 206));
        setContentPane(content);

        content.add(buildTopSection(), BorderLayout.NORTH);
        content.add(buildListSection(), BorderLayout.CENTER);
    }

    private JPanel buildTopSection() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        panel.add(buildRow(
                buildInputBlock("Dir IP", ipField),
                buildSummaryBlock("Clase", classValue, "M.RED", defaultMaskValue)
        ));
        panel.add(Box.createVerticalStrut(12));
        panel.add(buildRow(
                buildInputBlock("Host / Subred / Prefijo", hostField),
                buildSummaryBlock("Subredes", subnetCountValue, "Host", hostPerSubnetValue, "M.subred", newMaskValue, "Prefijo", prefixValue)
        ));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 4));
        buttons.setOpaque(false);
        JButton calculate = new JButton("Calcular");
        calculate.setBackground(new Color(255, 215, 0));
        calculate.setFocusPainted(false);
        calculate.addActionListener(this::runCalculation);
        buttons.add(calculate);
        panel.add(Box.createVerticalStrut(6));
        panel.add(buttons);
        panel.add(Box.createVerticalStrut(6));

        return panel;
    }

    private JPanel buildRow(JPanel left, JPanel right) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(false);
        row.add(left, BorderLayout.CENTER);
        row.add(right, BorderLayout.EAST);
        return row;
    }

    private JPanel buildInputBlock(String labelText, JTextField field) {
        JPanel block = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        block.setOpaque(false);

        JLabel label = new JLabel("<html>" + labelText.replace("/", "/<br>") + "</html>", SwingConstants.CENTER);
        label.setOpaque(true);
        label.setBackground(new Color(255, 152, 37));
        label.setForeground(Color.WHITE);
        label.setPreferredSize(new Dimension(140, 60));
        label.setFont(new Font("SansSerif", Font.BOLD, 16));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setVerticalAlignment(SwingConstants.CENTER);

        field.setPreferredSize(new Dimension(300, 40));
        field.setFont(new Font("SansSerif", Font.PLAIN, 18));
        field.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));

        block.add(label);
        block.add(field);
        return block;
    }

    private JPanel buildSummaryBlock(String title1, JLabel value1, String title2, JLabel value2) {
        JPanel block = baseSummaryPanel();
        block.setLayout(new GridLayout(2, 1, 0, 6));
        block.add(buildSummaryLabel(title1, value1));
        block.add(buildSummaryLabel(title2, value2));
        return block;
    }

    private JPanel buildSummaryBlock(String title1, JLabel value1, String title2, JLabel value2, String title3, JLabel value3, String title4, JLabel value4) {
        JPanel block = baseSummaryPanel();
        block.setLayout(new GridLayout(4, 1, 0, 4));
        block.add(buildSummaryLabel(title1, value1));
        block.add(buildSummaryLabel(title2, value2));
        block.add(buildSummaryLabel(title3, value3));
        block.add(buildSummaryLabel(title4, value4));
        return block;
    }

    private JPanel baseSummaryPanel() {
        JPanel block = new JPanel();
        block.setPreferredSize(new Dimension(240, 150));
        block.setBackground(new Color(82, 166, 80));
        block.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        block.setOpaque(true);
        return block;
    }

    private JPanel buildSummaryLabel(String title, JLabel valueLabel) {
        JPanel row = new JPanel(new BorderLayout(6, 0));
        row.setOpaque(false);

        JLabel titleLabel = new JLabel(title + ": ");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));

        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));

        row.add(titleLabel, BorderLayout.WEST);
        row.add(valueLabel, BorderLayout.CENTER);
        return row;
    }

    private JPanel buildListSection() {
        JPanel lists = new JPanel(new GridLayout(1, 2, 14, 0));
        lists.setOpaque(false);

        lists.add(buildListBlock("Lista de subredes", subnetList));
        lists.add(buildListBlock("Lista de host de la subred seleccionada", hostList));

        subnetList.setBackground(new Color(82, 166, 80));
        subnetList.setForeground(Color.WHITE);
        subnetList.setFont(new Font("Monospaced", Font.PLAIN, 14));
        subnetList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        hostList.setBackground(new Color(82, 166, 80));
        hostList.setForeground(Color.WHITE);
        hostList.setFont(new Font("Monospaced", Font.PLAIN, 14));
        hostList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        subnetList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updateHostList();
            }
        });

        return lists;
    }

    private JPanel buildListBlock(String title, JList<String> list) {
        JPanel block = new JPanel(new BorderLayout());
        block.setOpaque(false);

        JLabel header = new JLabel(title, SwingConstants.CENTER);
        header.setOpaque(true);
        header.setBackground(Color.WHITE);
        header.setForeground(Color.BLACK);
        header.setFont(new Font("SansSerif", Font.BOLD, 16));
        header.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        block.add(header, BorderLayout.NORTH);
        block.add(scrollPane, BorderLayout.CENTER);
        block.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        return block;
    }

    private void runCalculation(ActionEvent event) {
        String ip = ipField.getText().trim();
        int desiredHosts;

        try {
            desiredHosts = Integer.parseInt(hostField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa un número válido de hosts.", "Dato inválido", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int defaultPrefix = IpCalculatorOperations.getDefaultPrefix(ip);
        if (defaultPrefix < 0) {
            JOptionPane.showMessageDialog(this, "La dirección IP no es válida o no pertenece a clases A, B o C.", "IP inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int prefix = IpCalculatorOperations.calculatePrefixForHosts(desiredHosts);
        if (prefix < 0) {
            JOptionPane.showMessageDialog(this, "La cantidad de hosts excede el tamaño de una red IPv4.", "Límite superado", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (prefix < defaultPrefix) {
            JOptionPane.showMessageDialog(this, "Los hosts requeridos no caben en la red por defecto de esta clase.", "No compatible", JOptionPane.WARNING_MESSAGE);
            return;
        }

        currentIp = ip;
        currentPrefix = prefix;

        String ipClass = IpCalculatorOperations.getIpClass(ip);
        long subnets = IpCalculatorOperations.calculateSubnetCount(ip, prefix);
        long hostsPerSubnet = IpCalculatorOperations.calculateHostsPerSubnet(prefix);
        String defaultMask = IpCalculatorOperations.getDefaultMask(ip);
        String newMask = IpCalculatorOperations.getMaskFromPrefix(prefix);

        classValue.setText(ipClass);
        defaultMaskValue.setText(defaultMask);
        subnetCountValue.setText(String.valueOf(subnets));
        hostPerSubnetValue.setText(String.valueOf(hostsPerSubnet));
        newMaskValue.setText(newMask);
        prefixValue.setText("/" + prefix);

        loadSubnets();
        updateHostList();
    }

    private void loadSubnets() {
        subnetListModel.clear();
        if (currentPrefix < 0) {
            return;
        }
        List<String> subnets = IpCalculatorOperations.listSubnets(currentIp, currentPrefix, 512);
        for (String subnet : subnets) {
            subnetListModel.addElement(subnet);
        }
        if (!subnetListModel.isEmpty()) {
            subnetList.setSelectedIndex(0);
        }
    }

    private void updateHostList() {
        hostListModel.clear();
        int selectedIndex = subnetList.getSelectedIndex();
        if (selectedIndex < 0 || currentPrefix < 0) {
            return;
        }
        List<String> hosts = IpCalculatorOperations.listHostsForSubnet(currentIp, currentPrefix, selectedIndex, 256);
        for (String host : hosts) {
            hostListModel.addElement(host);
        }
    }

    private JLabel createValueLabel(String text) {
        JLabel label = new JLabel(text);
        label.setHorizontalAlignment(SwingConstants.LEFT);
        return label;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CalculatorUI().setVisible(true));
    }
}
